package yuvplayer.yuvplayer;

import android.annotation.SuppressLint;
import android.content.Context;
import android.opengl.GLSurfaceView;
import android.util.AttributeSet;
import android.view.SurfaceHolder;

public class YUVPlayer extends GLSurfaceView implements  Runnable,SurfaceHolder.Callback
{

    public YUVPlayer(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        new Thread(this).start();//回调run
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {

    }


    @SuppressLint("SdCardPath")
    @Override
    public void run() {//传GLSurfaceView地址进去

//    Open("/sdcard/outCat.yuv",getHolder().getSurface());
//    Open("/sdcard/Android/data/com.joyy.nativecpp/cache/v1080.yuv",getHolder().getSurface());
//    Open("/sdcard/Android/data/yuvplayer.yuvplayer/cache/out.yuv",getHolder().getSurface());
   Open("/sdcard/Android/data/yuvplayer.yuvplayer/cache/out.yuv",getHolder().getSurface());
    // Open("/sdcard/Android/data/yuvplayer.yuvplayer/v1080.yuv",getHolder().getSurface());

    }


    public  native void Open(String url,Object surface);



}
